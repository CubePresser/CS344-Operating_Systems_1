Compile as follows

gcc smallsh.c -o smallsh
